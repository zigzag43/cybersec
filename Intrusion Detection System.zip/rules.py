# rules.py
from utility import find_local_ip
# Global rules dictionary
rules = {
    'suspicious_ports': [8080, 8000, 21, 22, 23, 25, 110, 143, 3306, 3389, 1433],  # Common ports + SQL Server
    'suspicious_ip': [
    '10.0.0.1',      # Local network IP
    '203.0.113.1',   # Example IP address for documentation
    '8.8.8.8',       # Google Public DNS
    '8.8.4.4',       # Google Public DNS
    '1.1.1.1',       # Cloudflare DNS
    '1.0.0.1',       # Cloudflare DNS
    '185.60.216.35', # Known for spam and malicious activities
    '45.32.16.118',  # Known IP for malware hosting
    '35.187.224.48', # Google Cloud IP address
    '104.16.0.0',    # Cloudflare IP range
    '199.16.156.0',  # Known for malicious activity
    '104.244.42.1',  # Known proxy server
    '192.0.2.0',     # Documentation and example IP address
    '198.51.100.0',  # Documentation and example IP address
    '203.0.113.0'    # Documentation and example IP address
    ],
    'suspicious_payloads': [
        b'cmd.exe',
        b'/etc/passwd',
        b'<?php',
        b'base64',
        b'--><script>',
        b'root:root',
        b'wp-admin',
        b'etc/passwd',
        b'boot.ini',
        b'log4j',
        b'$.ajax({url: "/malicious",...',
        b'CVE-2021-22986',  # Example CVE pattern
        b'CVE-2021-22987',  # Example CVE pattern
        b'vulnerable_code_snippet'  # Placeholder for specific CVE patterns
    ],
    'suspicious_file_types': [
        b'.exe',
        b'.dll',
        b'.bat',
        b'.sh',
        b'.js',
        b'.php',
        b'.vbs',
        b'.pyc',
    ],
    'suspicious_user_agents': [
        b'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        b'curl/7.68.0',
        b'Wget/1.21.1',
        b'Python-requests/2.25.1',
        b'Nikto/2.1.6',
        b'Burp Suite',
        b'ZAP Proxy',
    ],
    'known_malware_signatures': [
        b'4d5a90000300000004000000ffff0000b800000000000000',
        b'50524956415000000000000000000000000000000000000000000000000000000000',
        b'5a5a5a5a5a5a5a5a',
        b'fffbfbd0d',
        b'60a0e0000000e00c0',
        b'4d5a90000300000004000000ffff0000b800000000000000',
    ],
    'suspicious_behaviors': [
        'attempted_login',
        'suspicious_file_access',
        'unusual_network_activity',
        'large_data_exfiltration',
    ],
    'suspicious_patterns': [
        b'EXEC XP_CMDSHELL',
        b'UNION SELECT',
        b'--',
        b'SELECT * FROM',
        b'GET /cgi-bin/',
        b'HTTP/1.1 301 Moved Permanently',
        b'HTTP/1.1 302 Found',
        b'CVE-2020-0601',  # Example CVE pattern
        b'CVE-2019-0708',  # Example CVE pattern
    ]
}

def get_rules():
    """Return the current rules."""
    return rules

def add_suspicious_ip(ip):
    """Add a new IP address to the suspicious IP list, excluding the local IP address."""
    local_ip = find_local_ip()
    if ip == local_ip:
        print(f"Cannot add local IP address: {ip}")
        return
    
    if ip not in rules['suspicious_ip']:
        if ip == local_ip:
            return
        else:
            rules['suspicious_ip'].append(ip)
            print(f"Added {ip} to suspicious IP rules.")

def inspect_packet(packet):
    """Generate alerts based on packet data and rules, and return alerts."""
    current_rules = get_rules()
    alerts = []

    # Check for suspicious ports
    if hasattr(packet, 'tcp') and int(packet.tcp.dstport) in current_rules['suspicious_ports']:
        alerts.append(f"Suspicious port detected: {packet.tcp.dstport}")

    # Check for suspicious IPs
    if hasattr(packet, 'ip') and packet.ip.src in current_rules['suspicious_ip']:
        alerts.append(f"Suspicious IP detected: {packet.ip.src}")

    return alerts

def inspect_packet_for_malware(packet):
    """Inspect the packet for potential malware signatures."""
    alerts = []
    rules = get_rules()
    
    # Check for suspicious payloads in packet data (if applicable)
    if hasattr(packet, 'raw_packet'):
        payload = packet.raw_packet.binary_value
        for pattern in rules['suspicious_payloads']:
            if pattern in payload:
                alerts.append(f"Malicious payload detected: {pattern.decode(errors='ignore')}")

        # Check for known malware signatures
        for signature in rules['known_malware_signatures']:
            if signature in payload:
                alerts.append(f"Malware signature detected: {signature.hex()}")

        # Check for suspicious patterns in payloads
        for pattern in rules['suspicious_patterns']:
            if pattern in payload:
                alerts.append(f"Suspicious pattern detected: {pattern.decode(errors='ignore')}")

    # Check for suspicious IPs
    src_ip = packet.ip.src if hasattr(packet, 'ip') else None
    if src_ip and src_ip in rules['suspicious_ip']:
        alerts.append(f"Malicious source IP detected: {src_ip}")

    # Check for suspicious ports
    if hasattr(packet, 'tcp') or hasattr(packet, 'udp'):
        port = packet.tcp.srcport if hasattr(packet, 'tcp') else (packet.udp.srcport if hasattr(packet, 'udp') else None)
        if port and int(port) in rules['suspicious_ports']:
            alerts.append(f"Suspicious port detected: {port}")

    return alerts
