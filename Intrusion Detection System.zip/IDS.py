import pyshark
import csv
import os
import pandas as pd
from datetime import datetime
from collections import deque
import time
import psutil
from rules import get_rules, inspect_packet, add_suspicious_ip, inspect_packet_for_malware


# Configuration
interface = 'eth0'  # Default interface, will be changed based on user input
log_data = []
packet_queue = deque()

# Request tracking configuration
REQUEST_THRESHOLD = 250
REQUEST_TIME_FRAME = 10  # in seconds
request_tracker = {}  # Track requests by IP

# Criteria for choosing method
MAX_LOG_ENTRIES_FOR_PANDAS = 1000 # Example threshold for switching to Pandas

def choose_log_method(log_data):
    """Choose the log saving method based on the number of log entries."""
    if len(log_data) > MAX_LOG_ENTRIES_FOR_PANDAS:
        return save_logs_to_csv_pandas
    else:
        return save_logs_to_csv_native

def save_logs_to_csv_native(log_data, filename='network_logs.csv'):
    """Save logs to a CSV file using the native CSV module."""
    file_exists = os.path.isfile(filename)
    with open(filename, mode='a', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=log_data[0].keys())
        if not file_exists:
            writer.writeheader()
        writer.writerows(log_data)
    print(f"Logs saved to {filename}")

def save_logs_to_csv_pandas(log_data, filename='network_logs.csv'):
    """Save logs to a CSV file using Pandas."""
    df = pd.DataFrame(log_data)
    file_exists = os.path.isfile(filename)
    df.to_csv(filename, mode='a', header=not file_exists, index=False)
    print(f"Logs saved to {filename}")

def generate_alerts(packet):
    """Generate alerts based on packet data and rules, and display packet details."""
    alerts = inspect_packet_for_malware(packet)
    
    # Initialize port variable
    port = 'N/A'

    # Display packet details
    print(f"\nPacket Details:")
    print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Source IP: {packet.ip.src if hasattr(packet, 'ip') else 'N/A'}")
    print(f"Destination IP: {packet.ip.dst if hasattr(packet, 'ip') else 'N/A'}")
    print(f"Protocol: {packet.transport_layer if hasattr(packet, 'transport_layer') else 'N/A'}")
    
    if hasattr(packet, 'tcp') or hasattr(packet, 'udp'):
        port = packet.tcp.srcport if hasattr(packet, 'tcp') else (packet.udp.srcport if hasattr(packet, 'udp') else 'N/A')
        print(f"Port: {port}")

    if alerts:
        for alert in alerts:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            log_entry = {
                'timestamp': timestamp,
                'source_ip': packet.ip.src if hasattr(packet, 'ip') else 'N/A',
                'destination_ip': packet.ip.dst if hasattr(packet, 'ip') else 'N/A',
                'protocol': packet.transport_layer if hasattr(packet, 'transport_layer') else 'N/A',
                'port': port,  # Use the port variable here
                'alert': alert
            }
            log_data.append(log_entry)
            print(f"ALERT: {alert}")
            save_method = choose_log_method(log_data)
            save_method([log_entry])  # Save only the new log entry


def analyze_logs():
    """Analyze logs and print alert counts."""
    filename = 'network_logs.csv'
    if os.path.isfile(filename):
        df = pd.read_csv(filename)
        alert_counts = df['alert'].value_counts()
        print("Alert Counts:")
        print(alert_counts)

def list_interfaces():
    """List available network interfaces using psutil."""
    interfaces = psutil.net_if_addrs()
    for i, iface in enumerate(interfaces):
        print(f"{i+1}. {iface}")

    return interfaces

def get_network_interface():
    """Prompt user to select a network interface, identifying Wi-Fi if present."""
    print("Select network interface:")
    interfaces = list_interfaces()
    
    wifi_interfaces = [iface for iface in interfaces if iface.startswith('wlan') or iface.startswith('wlp')]
    if wifi_interfaces:
        print("\nWi-Fi Interfaces:")
        for i, iface in enumerate(wifi_interfaces):
            print(f"{i+1}. {iface}")

    choice = input("Enter the number corresponding to your choice: ")
    
    try:
        choice = int(choice) - 1
        if 0 <= choice < len(interfaces):
            return list(interfaces.keys())[choice]
        else:
            raise ValueError
    except (ValueError, IndexError):
        print("Invalid choice. Defaulting to the first available interface.")
        return list(interfaces.keys())[0]

def process_packets(capture):
    """Process packets and update request tracker."""
    global request_tracker
    for packet in capture.sniff_continuously():
        src_ip = packet.ip.src if hasattr(packet, 'ip') else None
        if src_ip:
            now = datetime.now()
            if src_ip not in request_tracker:
                request_tracker[src_ip] = deque()
            
            # Remove requests outside the time frame
            request_tracker[src_ip] = deque([timestamp for timestamp in request_tracker[src_ip] if (now - timestamp).total_seconds() < REQUEST_TIME_FRAME])
            
            # Add the current request
            request_tracker[src_ip].append(now)
            
            # Check if the IP exceeds the threshold
            if len(request_tracker[src_ip]) >= REQUEST_THRESHOLD:
                add_suspicious_ip(src_ip)  # Add the IP to the rules
                
        generate_alerts(packet)
        
        # Optionally perform log analysis or other tasks
        if int(time.time()) % 600 == 0:  # Example: Every 10 minutes
            analyze_logs()

def main():
    """Main function to run the IDS."""
    global interface
    interface = get_network_interface()
    
    print(f"Using network interface: {interface}")

    # Start packet capture
    capture = pyshark.LiveCapture(interface=interface)
    print(f"Starting packet capture on {interface}...")

    try:
        process_packets(capture)
    except KeyboardInterrupt:
        print("Stopping capture...")
        # Save any remaining logs
        save_method = choose_log_method(log_data)
        save_method(log_data)

if __name__ == "__main__":
    main()
