import string
def caeser(message,key):
    shift = key % 26 
    chiper = str.maketrans(string.ascii_lowercase,string.ascii_lowercase[shift:]+ string.ascii_lowercase[:shift])
    encrypted_message = message.lower().translate(chiper)
    return encrypted_message
def decrpty(encrypted_message,key):
    shift = 26 -  (key % 26)
    chiper = str.maketrans(string.ascii_lowercase,string.ascii_lowercase[shift:] + string.ascii_lowercase[:shift])
    message = encrypted_message.translate(chiper)
    return message
message=input("enter message: ")
key = 3

encrypted_message= caeser(message,key)
print(f"encrypted message: {encrypted_message}")
decrypted=decrpty(encrypted_message,key)
print(f"encrypted message: {decrypted}")
