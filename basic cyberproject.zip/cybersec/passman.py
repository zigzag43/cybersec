# import hashlib
# import getpass
# password_man={}

# def create():
#     username=input("enter your name: ")
#     password=getpass.getpass("enter your password: ")
#     hased=hashlib.sha256(password.encode()).hexdigest()
#     password_man[username]= hased
#     print("account created sucessfully")

# def login():
#     username=input("enter your password: ")
#     password = getpass.getpass("enter password: ")
#     hased=hashlib.sha256(password.encode()).hexdigest()
#     if username in password_man.keys() and password_man[username]==hased:
#         print("login sucessfully")
#     else:
#         print("invalid username or password. ")


# def main():
#     while True:
#         choose= int(input(" 1 for singup 2 for login and 3 to exit"))
#         if choose == 1:
#             create()
#         if choose == 2:
#             login()
#         if choose== 3:
#             break


# if __name__=="__main__":
#     main()


