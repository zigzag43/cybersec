import yara
from utility import find_local_ip
import openai
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)

# Initialize the OpenAI API with your key
openai.api_key = 'your api cahtgpt 3.5 turbo '

# Global rules dictionary (keeping your existing rules)
rules = {
    'suspicious_ports': [8080, 8000, 21, 22, 23, 25, 110, 143, 3306, 3389, 1433],
    'suspicious_ip': ['10.0.0.1', '203.0.113.1', '8.8.8.8', '8.8.4.4', '1.1.1.1', '1.0.0.1', '185.60.216.35', '45.32.16.118', '35.187.224.48', '104.16.0.0', '199.16.156.0', '104.244.42.1', '192.0.2.0', '198.51.100.0', '203.0.113.0'],
    'suspicious_payloads': [b'cmd.exe', b'/etc/passwd', b'<?php', b'base64', b'--><script>', b'root:root', b'wp-admin', b'etc/passwd', b'boot.ini', b'log4j', b'$.ajax({url: "/malicious",...', b'CVE-2021-22986', b'CVE-2021-22987', b'vulnerable_code_snippet'],
    'suspicious_file_types': [b'.exe', b'.dll', b'.bat', b'.sh', b'.js', b'.php', b'.vbs', b'.pyc'],
    'suspicious_user_agents': [b'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', b'curl/7.68.0', b'Wget/1.21.1', b'Python-requests/2.25.1', b'Nikto/2.1.6', b'Burp Suite', b'ZAP Proxy'],
    'known_malware_signatures': [b'4d5a90000300000004000000ffff0000b800000000000000', b'50524956415000000000000000000000000000000000000000000000000000000000', b'5a5a5a5a5a5a5a5a', b'fffbfbd0d', b'60a0e0000000e00c0', b'4d5a90000300000004000000ffff0000b800000000000000'],
    'suspicious_behaviors': ['attempted_login', 'suspicious_file_access', 'unusual_network_activity', 'large_data_exfiltration'],
    'suspicious_patterns': [b'EXEC XP_CMDSHELL', b'UNION SELECT', b'--', b'SELECT * FROM', b'GET /cgi-bin/', b'HTTP/1.1 301 Moved Permanently', b'HTTP/1.1 302 Found', b'CVE-2020-0601', b'CVE-2019-0708']
}

# Define YARA rules as a string
yara_rules = '''
rule SuspiciousPayloads
{
    strings:
        $cmd = "cmd.exe"
        $passwd = "/etc/passwd"
        $php = "<?php"
        $base64 = "base64"
        $script = "--><script>"
        $root = "root:root"
    condition:
        any of them
}

rule KnownMalwareSignatures
{
    strings:
        $m1 = { 4d5a90000300000004000000ffff0000b800000000000000 }
        $m2 = { 50524956415000000000000000000000000000000000000000000000000000000000 }
        $m3 = { 5a5a5a5a5a5a5a5a }
    condition:
        any of them
}
'''

# Compile YARA rules
compiled_rules = yara.compile(source=yara_rules)

def get_rules():
    """Return the current rules."""
    return rules

def add_suspicious_ip(ip):
    """Add a new IP address to the suspicious IP list, excluding the local IP address."""
    local_ip = find_local_ip()
    if ip == local_ip:
        logging.warning(f"Cannot add local IP address: {ip}")
        return

    if ip not in rules['suspicious_ip']:
        rules['suspicious_ip'].append(ip)
        logging.info(f"Added {ip} to suspicious IP rules.")

def inspect_packet(packet):
    """Generate alerts based on packet data and rules, and return alerts."""
    current_rules = get_rules()
    alerts = []

    # Check for suspicious ports
    if hasattr(packet, 'tcp') and hasattr(packet.tcp, 'dstport') and int(packet.tcp.dstport) in current_rules['suspicious_ports']:
        alerts.append(f"Suspicious port detected: {packet.tcp.dstport}")

    # Check for suspicious IPs
    if hasattr(packet, 'ip') and hasattr(packet.ip, 'src') and packet.ip.src in current_rules['suspicious_ip']:
        alerts.append(f"Suspicious IP detected: {packet.ip.src}")

    return alerts


def get_remediation_suggestions(alert):
    """Query ChatGPT for remediation suggestions based on the alert."""
    prompt = f"Given the following alert, provide a remediation suggestion: {alert}"

    try:
        # Make the API call to OpenAI
        response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a cybersecurity expert."},
        {"role": "user", "content": prompt}
    ]
)
     
        # Extract the remediation suggestion from the response
        remediation = response['choices'][0]['message']['content'].strip()
        return remediation
    except Exception as e:
        return f"Error in generating remediation: {str(e)}"


def inspect_packet_for_malware(packet):
    """Inspect the packet for potential malware signatures and provide remediation suggestions using ChatGPT."""
    alerts = []
    results = []
    rules = get_rules()

    # Check for suspicious payloads in packet data (if applicable)
    if hasattr(packet, 'raw_packet') and hasattr(packet.raw_packet, 'binary_value'):
        payload = packet.raw_packet.binary_value

        # Match YARA rules
        matches = compiled_rules.match(data=payload)
        for match in matches:
            alerts.append(f"YARA rule matched: {match.rule}")

        # Check for known malware signatures
        for signature in rules['known_malware_signatures']:
            if signature in payload:
                alerts.append(f"Malware signature detected: {signature.hex()}")

        # Check for suspicious patterns in payloads
        for pattern in rules['suspicious_patterns']:
            if pattern in payload:
                alerts.append(f"Suspicious pattern detected: {pattern.decode(errors='ignore')}")

    # Check for suspicious IPs
    src_ip = packet.ip.src if hasattr(packet, 'ip') and hasattr(packet.ip, 'src') else None
    if src_ip and src_ip in rules['suspicious_ip']:
        alerts.append(f"Malicious source IP detected: {src_ip}")

    # Check for suspicious ports
    port = None
    if hasattr(packet, 'tcp') and hasattr(packet.tcp, 'srcport'):
        port = packet.tcp.srcport
    elif hasattr(packet, 'udp') and hasattr(packet.udp, 'srcport'):
        port = packet.udp.srcport

    if port and int(port) in rules['suspicious_ports']:
        alerts.append(f"Suspicious port detected: {port}")

    # Query ChatGPT for remediation suggestions
    for alert in alerts:
        remediation = get_remediation_suggestions(alert)
        results.append(f"{alert} - Remediation: {remediation}")

    return results
